# gaston11276 pushcar NFive Plugin
[![License](https://img.shields.io/github/license/gaston11276/pushcar.svg)](LICENSE)
[![Build Status](https://img.shields.io/appveyor/ci/gaston11276/pushcar/master.svg)](https://ci.appveyor.com/project/gaston11276/pushcar)
[![Release Version](https://img.shields.io/github/release/gaston11276/pushcar/all.svg)](https://github.com/gaston11276/pushcar/releases)

NFive Plugin

## Installation
Install the plugin into your server from the [NFive Hub](https://hub.nfive.io/gaston11276/pushcar): `nfpm install gaston11276/pushcar`
